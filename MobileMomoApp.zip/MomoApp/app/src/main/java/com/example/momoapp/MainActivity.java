package com.example.momoapp;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    EditText txtName;
    TextView showName;
    Button btnSubmit;
    Button btnNav;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnSubmit = findViewById(R.id.btnSubmit);
        btnNav = findViewById(R.id.btnNav);
        txtName = findViewById(R.id.txtName);
        showName = findViewById(R.id.showName);

        btnSubmit.setOnClickListener(this);
        btnNav.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.btnSubmit) {
            String enteredName = txtName.getText().toString();
            showName.setText(enteredName+", Welcome To Use Simple Mobile Money App!!!, Click Send Money To Continue.... ");

        }
        if (v.getId() == R.id.btnNav){
            Intent  i = new Intent(MainActivity.this, nextActivity.class);
            startActivity(i);
        }
    }
}
