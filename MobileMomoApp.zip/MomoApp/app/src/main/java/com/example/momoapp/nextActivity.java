package com.example.momoapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class nextActivity extends AppCompatActivity implements View.OnClickListener{
    Button btnSend;
    EditText txtAmount;
    EditText txtPhone;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_next);

        btnSend = findViewById(R.id.btnSend);
        txtAmount = findViewById(R.id.txtAmount);
        txtPhone = findViewById(R.id.txtPhone);

        btnSend.setOnClickListener(this);
    }

    @Override
    public void onClick(@NonNull View v) {
        if (v.getId() == R.id.btnSend) {
            String phone = txtPhone.getText().toString();
            String amount = txtAmount.getText().toString();
            String ussdCode = "*182*1*1*" + phone + "*" + amount + Uri.encode("#");

            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse("tel:" + ussdCode));
            startActivity(intent);
        }
    }

}